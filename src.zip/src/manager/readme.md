# 第十六届蓝桥杯大赛（软件组）省赛–河海大学赛点-技术文档——2025.4.12

* 请完整按照以下流程进行操作，如有问题请及时在群内反馈
* 网盘 （`https://alist.imgxt.com`）因有敏感信息，已关闭游客登录，**登录账号密码均为`lanqiao`**
* 每个机房制作了专属该机房的蓝桥杯系统，取名为``房间号-第16届蓝桥杯比赛`系统`，并且没有重启还原功能，进系统时请注意选择正确系统

## 一、机器开机并清空编辑层

1. 开启教师机（讲台机器），需手动找到机箱位置进行开机。
2. 教师机开机后，找到桌面“噢易多媒体网络教室软件（教师端）”软件（下文简称教师软件），双击打开并登录，点击右上角`上课`，选择`xxx-第16届蓝桥杯比赛`系统，保存确定，关闭窗口
3. 单击教师端导航栏`远程开机`，等待所有机器开启后，请机房技术人员登录噢易管理面板，对蓝桥杯系统进行清空还原，确保没有残留代码文件
4. 重启电脑，进入机房`xxx-第16届蓝桥杯比赛`系统

* **注：`xxx-第16届蓝桥杯比赛`系统是不还原系统，考生不慎关机或断电不会造成代码丢失**

## 二、开启赛点服务器

1. 前往网盘 （`https://alist.imgxt.com`）**登录账号密码均为`lanqiao`**，下载`第十六届蓝桥杯大赛比赛服务器程序（软件赛）.rar`并解压至桌面，**如果已解压请删除之前的客户端，重新解压清空缓存**
2. **拔出备份U盘。**
3. 进入解压后的 `第十六届蓝桥杯大赛比赛服务器程序（软件赛）` 文件夹，解压 `ExamPServer1.6_软件.rar`。
4. 进入解压后的 `ExamPServer` 目录，双击打开 `ExamServer.bat` 等待 `Tomcat` 服务器开启。若弹出 `Windows 安全中心警报`，点击左下角 `允许访问`，**浏览器将自动跳转至 `http://127.0.0.1/adm/index.page`（若无跳转请手动访问 `http://127.0.0.1`）。**
5. 查看网盘`赛点服务器登录信息`，输入考场编号与登录密码进行登录。
6. 等待网页左上角显示“服务器已连接”，试题和用户数据将自动导入。
7. **设置考点服务器标识**：点击左上角 `设置考点服务器`，输入机房名称（如：致远楼503）。
8. 插入备份U盘，等待页面刷新U盘状态。若无法识别，请拔下后等待30秒再插入，然后刷新页面。
9. 检查U盘目录下是否生成 `LanqiaoBackup` 目录且内容非空。

## 三、考生机器环境检查

### 1. **弹窗程序初始化**

1. 教师机进入网盘的`contest-manager`目录下载`contest-manage-main.zip`和对应机房的配置信息（包含一个client和config）

2. 检查`教师机`python版本是否为`3.13+`——打开cmd，输入`python --version`得到版本号，若版本低于`3.13`，请前往网盘的`contest-manager`目录，下载最新安装包并安装

3. 将``contest-manage-main.zip``解压至桌面，**如果已经有旧的版本，请进入旧版本删除`src`目录，脱入最新版，请勿直接覆盖**，然后可以跳过操作4

4. **如果打算重新配置（建议重新配置）**，请使用cmd进入解压后的目录（**打开当前目录文件夹，点击地址栏，删除所有内容，输入cmd即可在当前目录进入cmd**），确保目录下有`src和requirements.txt`（输入`dir`查看当前目录文件），cmd窗口输入`python -m venv env`创建虚拟环境

5. cmd窗口输入`env\Scripts\activate.bat`激活虚拟环境，**此时窗口会刷新，并且在用户名前回显示`(env)`**

   ```
   (env) xxxx\src\Scripts
   ```

6. 确保目录下有`src和requirements.txt`（输入`dir`查看当前目录文件），cmd窗口输入`pip install -r requirements.txt`安装依赖，等待安装完成

7. cmd窗口将下载的client和config解压覆盖至`src\manager`目录，用记事本打开`config.json`确认一下机房信息正确，且`client.xlsx`为当前机房考生信息

8. cmd窗口输入`cd src\manager`进入管理端目录，**如果不慎关闭了这个窗口，请回到第五步重新激活虚拟环境**

### 2. 机器连通行检查，用于获取实际开机的机器数

* cmd窗口输入`python main.py ping`进行机器连通性检查，确认可用机器数正确（对比噢易教师端在线数），根据提示确认不可用机器是否与座位表的空缺编号一致（也可以参照噢易多媒体网络教室软件（教师端）的机器数），**请不要使用`update-client-list`方法，如果不慎使用，请重新下载`client.xlsx`并进行覆盖**
* **部分机房有机器系统故障，请直接关闭该机器，以免影响后续下发操作**

### 3. 开启考生机器弹窗客户端

* 进入“噢易多媒体网络教室软件（教师端）”，全选所有机器，点击导航栏的`远程命令`，**将命令路径替换为`C:\lanqiao\client\start_client.bat`**，点击左下角执行，如果有报错弹窗不用管，点击左侧日志按钮得到的都是成功即可

### 4. 检查考生机器是否成功进入蓝桥杯系统并开启了弹窗客户端

* cmd窗口输入`python main.py connect-check`检查连通性，**注意，这步操作的目的是检查是否所有的考生机已经进入了蓝桥杯系统，并且开启了客户端，如果有`fail`请根据日志检查对应机器进行排查**，此时应该得到全部成功，0台失败 ，如果有失败请在群中呼叫
* **这步操作在赛时可以经常执行，目的是查看是否有机器与赛点服务器失联**

### 5. 下发考生信息

* cmd窗口输入`python main.py set-client-info`下发考生用户信息，此时应该得到全部成功，0台失败 

### 6. **配置学生机网络限制**

1. 进入教师软件，点击导航栏 `行为管控`（若未找到请切换页面或手动添加）。

2. 进入左侧 `网络使用限制` 选项。

3. 勾选右侧 `禁用外网`，点击下方 `确定` 保存设置。

4. **外网连通性测试，针对断网需求**

   1. 将`src\manager`目录下的`command.json`替换为`command-template`下的`ping-baidu`

      ```json
      {
          "command": "f'ping baidu.com -n 1'"
      }
      ```

   2. cmd窗口输入`python main.py run-command`，**这步时间比较久，因为要等待返回错误信息**，这步将尝试在所有考生机测试外网连通行，此时应该得到全部成功，0台失败，然后查看`src\manager`下的`command-log.json`，应该全部得到的是`解析出错`等字样

### 7. 学生机访问赛点服务器测试

1. 将`src\manager`目录下的`command.json`替换为`command-template`下的`open-chrome`

```json
{
    "command": "f'start chrome.exe {LOCAL_IP}'"
}
```

2. cmd窗口输入`python main.py run-command`，**这步将在所有机器上开启浏览器并访问赛点服务器**，请检查是否每台机器都开启时浏览器并且访问到了蓝桥杯比赛服务器

* **这个页面可以留着，后续弹出的信息窗口会至于最顶层，不必担心被浏览器覆盖**

3. 如果你需要关闭所有考生机的chrome，将`src\manager`目录下的`command.json`替换为`command-template`下的`close-chrome`，后续操作同上

### 8. 考生机器环境检查

1. 将`src\manager`目录下的`command.json`替换为`command-template`下的`env-check`

   ```json
   {
       "command": "f'python --version && java -version && gcc --version && node -v'"
   }
   ```

2. cmd窗口输入`python main.py run-command`检查考生机器环境是否正常，随后用记事本打开`src\manager`下的`command-log.json`，查询每条返回记录是否都返回了正确的版本号，翻看一下：

   * python 3.8.6
   * java 1.8.0
   * gcc 4.9.2
   * node 12+

## 四、 弹出考生信息窗口

1. cmd窗口输入`python main.py open-info-window 1`开启考生信息窗口，此时应该得到全部成功，0台失败 ，**关闭则是输入``python main.py close-info-window 1``**

2. 进入“噢易多媒体网络教室软件（教师端）”，对没有弹窗的机器和坏机器进行计数，数量应该满足`总机器数 = 考生人数（有弹窗的）+ 坏机器（开不了机的）+ 备用机（没有弹窗但开机的）`

## 五、云监考设置

进入腾讯会议，将个人名称修改为“赛点名称+机房名称”

**河海大学，腾讯会议号：883-526-311**

## 六、检查考生比赛机位，保持整洁，无参考资料

## 七、考生机位示意图大屏投放

1. 下载`第十六届蓝桥杯全国软件和信息技术专业人才大赛省赛河海大学赛点考生机位示意图.xlsx`
2. 进行投屏，**建议将教师机屏幕拓展方式改为`扩展`**，快捷键是`win + P`进行切换，将大屏幕投放机位示意图

## 八、各时间段公告弹窗

### 各时间段弹窗

* 各弹窗考生可以手动关闭，请各机房根据实际情况再运行一次统一关闭指令

#### 8:45赛场须知

1. 将`src\manager`目录下的`window.json`替换为`window-template`下的`8-45`

2. cmd窗口输入`python main.py open-info-window 2`，**关闭则是输入``python main.py close-info-window 2``**

* **注意命令末尾的编号**

#### 10：00注意事项

1. 将`src\manager`目录下的`window.json`替换为`window-template`下的`10`

2. cmd窗口输入`python main.py open-info-window 3`，**关闭则是输入``python main.py close-info-window 3``**

* **注意命令的编号**

#### 12：45提醒提交

1. 将`src\manager`目录下的`window.json`替换为`window-template`下的`12-45`

2. cmd窗口输入`python main.py open-info-window 4`，**关闭则是输入``python main.py close-info-window 4``**

* **注意命令的编号**

#### 13:00结束通告

1. 将`src\manager`目录下的`window.json`替换为`window-template`下的`13`

2. cmd窗口输入`python main.py open-info-window 5`，**关闭则是输入``python main.py close-info-window 5``**

* **注意命令的编号**

## 九、试题解压密码下发

1. 将`src\manager`目录下的`window.json`替换为`window-template`下的`password`，**并替换`password`为解压密码**

   ```json
   {
       "title": "解压密码",
       "content": "f'解压密码：password'",
       "front_size": 50
   }
   ```

2. cmd窗口输入`python main.py open-info-window 10`，**关闭则是输入``python main.py close-info-window 10``**

   * **注意命令的编号**

3. 也可以新建一个记事本，放入密码然后用文件下发操作，

   1. 将待下发文件放在桌面
   2. 进入教师软件，`ctrl + a`全选机器，点击导航栏 `下发作业`。
   3. 右键单击要发的文件，选择 `发送文件`。
   4. 等待文件传输进度完成
   5. 不要发大文件，这是噢易系统的问题

## 换机操作

1. 禁止考生自行重启计算机，如果蓝屏卡死请各赛点技术手动重启，操作开始时记录起始时间，**重启进入系统时请手动选择``xxx-第16届蓝桥杯比赛`系统**，绝大多数情况应该无需换机，**重启后请跳至下文第6步进行操作**

2. 如果需要换机，**需要在考场服务器管理面板（教师机访问`http://127.0.0.1`）对选手状态进行更改**

3. 换机后，请先检查**该考生**环境是否正常，不用检查所有

   ```
   python --version
   java -version
   gcc --version
   node -v
   ```

4. 访问赛点服务器（新机器机房的教师机IP），协助考生登录

5. 请记录新机器的ip，**回到对应机房教师机更改`src\manager`下的`client.xlsx`中的`考生机器IP`**，如果是其他考场的考生，请新增记录，同步删除旧考场该考生的记录

6. 进入“噢易多媒体网络教室软件（教师端）”，选择新机器，点击导航栏的`远程命令`，**将命令路径替换为`C:\lanqiao\client\start_client.bat`**，点击左下角执行，如果有报错弹窗不用管，点击左侧日志按钮得到的都是成功即可

7. cmd窗口输入`python main.py connect-check`检查机器连通性，查看是否恢复连通

8. **这步可选**：cmd窗口输入`python main.py set-client-info`下发考生用户信息，


